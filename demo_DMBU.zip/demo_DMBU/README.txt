There are two demos for displaying DMBU.

demo.m is used to test the proposed approach.  
The user can select "test = 1" or "test = 2" to run the demo of the DMBU.
1) The real hyperspectral data would be used to test the approach if you select "test = 1".
2) The synthetic data (simulated hyperspectral data) would be used if you select "test = 2".

demo_other_nonlinear_unmixing.m is a comparision for some nonlinear algorithms.
Please use MATLAB 2016 or later.

Yuanchao, July 2th, 2019
