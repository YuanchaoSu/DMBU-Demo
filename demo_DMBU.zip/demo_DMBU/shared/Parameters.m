function [Parameter] = Parameters()
%%   This function sets the parameters to be used for LRMFMT
Parameter.coeff = 1e-4;% balance
% Parameter.coeff = 1e-3;% balance
Parameter.mu = 0.9;% balance
% Parameter.mu = 0.5;% balance
Parameter.eps = 1e-3;% nonzero
Parameter.theta = 2e-3; 
Parameter.eta = 5e-3;
Parameter.lambda = 4e-3;
Parameter.psi = 23;
Parameter.layers = 3;
end